<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="$_GET">
        <input type="number" name="numero" placeholder="Digite um numero entre 100 e 200">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if(isset($_GET["numero"])){
        $numero = $_GET["numero"];
        if($numero > 100 && $numero < 200){
            echo $numero . " esta entre 100 e 200";
        }elseif($numero <= 100){
            echo $numero . " é menor ou igual que 100";
        }else{
            echo $numero . " é maior ou igual 200";
        }
    }
    ?>
</body>
</html>