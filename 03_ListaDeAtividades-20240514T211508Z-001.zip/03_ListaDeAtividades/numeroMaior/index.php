<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method="$_GET">
        <input type="number" name="numero1" placeholder="Digite o primeiro número">
        <input type="number" name="numero2" placeholder="Digite o segundo número">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if(isset($_GET["numero1"]) && isset($_GET["numero2"])){
        $numero1 = $_GET["numero1"];
        $numero2 = $_GET["numero2"];
        if($numero1 > $numero2){
            echo $numero1 . " é maior";
        }elseif($numero2 > $numero1){
            echo $numero2 . " é maior";
        }elseif($numero1 == $numero2){
            echo $numero1 . " e " . $numero2 . " são iguais";
        }else{
            echo "ERRO!! por favor tente novamente";
        }
    }
    ?>
</body>
</html>