<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method = "$_GET">
        <input type="number" name="valorProduto" placeholder = "Informe o valor do produto">
        <input type="submit" value = "Enviar">
    </form>

    <?php
    if(isset($_GET["valorProduto"])){
        $valorProduto = $_GET["valorProduto"];
        $prestacoes = $valorProduto / 5;
        echo "O valor do seu produto é: " . $valorProduto . ", você poderá pagá-ço em 5 prestações de: " . $prestacoes;
    }
    ?>
</body>
</html>