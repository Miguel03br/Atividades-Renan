<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form action="" method="GET">
        <input type="text" name="Nome" placeholder="Digite seu nome">
        <input type="number" name="Nota1" placeholder="Digite sua primeira nota">
        <input type="number" name="Nota2" placeholder="Digite sua segunda nota">
        <input type="number" name="Nota3" placeholder="Digite sua terceira nota">
        <input type="submit" value="Enviar">
    </form>

    <?php
        if(isset($_GET["Nota1"]) && isset($_GET["Nota2"]) && isset($_GET["Nota3"]) && !empty($_GET["Nota1"]) && !empty($_GET["Nota2"]) && !empty($_GET["Nota3"])){
            $nome = $_GET["Nome"];
            $nota1 = $_GET["Nota1"];
            $Nota2 = $_GET["Nota2"];
            $Nota3 = $_GET["Nota3"];
            $media = ($nota1 + $Nota2 + $Nota3)/ 3;

            if($media >= 7 && $media <= 10){
                echo"Olá ".$nome ." sua média é " . $media . ", você está aprovado";
            }elseif($media >= 5.1 && $media <= 6.9){
                echo"Olá ".$nome ." sua média é " . $media . ", você está de recuperação";
            }elseif($media >=0 && $media <= 5){
                echo"Olá ".$nome ." sua média é " . $media . ", você está reprovado";
            }elseif($Nota1 < 0 || $nota1 > 10 || $Nota2 < 0 || $nota2 > 10 || $Nota3 < 0 || $Nota3 > 10 || $media < 0 || $media > 10){
                echo"Infelizmente algum valor está errado, por favor tente inserir os dados novamente";
            }
        }
    ?>
</body>
</html>