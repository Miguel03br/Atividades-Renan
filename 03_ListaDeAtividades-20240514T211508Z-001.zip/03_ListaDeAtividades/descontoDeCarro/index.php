<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form action="" method="GET">
        <input type="number" name="Carro" placeholder="Quantos carros você deseja comprar">
        <input type="number" namer="AnoCarro" placeholder="Qual o ano do carro que deseja comprar?">
        <input type="submit" value="Enviar">
        
        <?php
        if(isset($_GET["Carro"]) && isset($_GET["AnoCarro"]) && !empty($_GET["Carro"]) && !empty($_GET["AnoCarro"])){
            $Carro = $_GET["Carro"];
            $AnoCarro = $_GET["AnoCarro"];

            if($AnoCarro >= 1000 && $AnoCarro <= 2000){
                echo "Você terá 12% de desconto na sua compra";
            }elseif($AnoCarro > 2000 && $AnoCarro <= 3000){
                echo "Você terá 7% de desconto na sua compra";
            }

            
        }
        ?>
    </form>
</body>
</html>