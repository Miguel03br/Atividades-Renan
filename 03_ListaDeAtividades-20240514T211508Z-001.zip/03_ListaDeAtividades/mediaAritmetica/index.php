<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css">
  
  <!-- bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
</head>
<body>
  <form action="" method="GET">
  <input type="text" name="nome" placeholder="Nome do aluno">
  <input type="number" name="nota1" placeholder="Digite a nota 1">
  <input type="number" name="nota2" placeholder="Digite a nota 2">
  <input type="number" name="nota3" placeholder="Digite a nota 3">
  <input type="submit" value="Enviar">
  </form>

  <?php
  if(isset($_GET["nome"]) && isset($_GET["nota1"]) && isset($_GET["nota2"]) && isset($_GET["nota3"])){
    $nome = $_GET["nome"];
    $nota1 = $_GET["nota1"];
    $nota2 = $_GET["nota2"];
    $nota3 = $_GET["nota3"];
    $media = ($nota1 + $nota2 + $nota3) / 3;
    echo "Olá ". $nome . " sua nota média: " . $media;
  }
  ?>
  
  <!-- bootstrap -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>