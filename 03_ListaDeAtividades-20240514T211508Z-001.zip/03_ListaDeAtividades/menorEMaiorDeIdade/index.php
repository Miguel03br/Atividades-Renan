<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form action="" method="GET">
        <input type="number" name="idade" placeholder="Informe uma idade">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if(isset($_GET["idade"]) && !empty($_GET["idade"])){
        $Idade = $_GET["idade"];
        $QuantidadeIdade = $Idade * 75;

        while($idade=rand($Idade,$QuantidadeIdade)){
            echo $Idade;
    
            if($Idade < 0 || $Idade > 100){
                echo "Este número é menor 0 ou maior que 100, por favor tente outros números";
            }elseif($Idade <= 17 && $Idade > 0 &&$Idade < 100){
                echo $Idade , " = menor de idade";
            }elseif($Idade >= 18 && $Idade > 0 &&$Idade < 100){
                echo $Idade , " = maior de idade";
            }
        }
    }
    ?>
</body>
</html>