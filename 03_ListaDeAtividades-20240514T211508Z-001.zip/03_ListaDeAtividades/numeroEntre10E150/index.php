<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <form action="" method="GET">
        <input type="number" name="Numero" placeholder="Digte um número">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if(isset($_GET["Numero"]) && !empty($_GET["Numero"])){
        $Numero = $_GET["Numero"];
        $NumeroLimite = $Numero * 80;

        while($Numero <= $NumeroLimite){
            // echo $Numero . "<br>";
            $Numero++;

            if($Numero >= 10 && $Numero <= 150){
                echo $Numero . " está entre 10 e 150<br>";
            }
        }
    }
    ?>
</body>
</html>