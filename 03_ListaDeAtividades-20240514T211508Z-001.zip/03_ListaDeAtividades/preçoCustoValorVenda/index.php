<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="" method = "$_GET">
        <input type="number" name = "precoCusto" placeholder = "Informe o preço de custo do produto">
        <input type="number" name = "porcentagem" placeholder = "Iforme uma porcentagem para o número acima">
        <input type="submit" value = "Enviar">
    </form>

    <?php
    if(isset($_GET["precoCusto"]) && isset($_GET["porcentagem"])){
        $preco = $_GET["precoCusto"];
        $porcentagem = $_GET["porcentagem"];
        $valorVenda = $preco + ($porcentagem / 100);
        echo "Seu preço de custo é: " . $preco . " e seu valor de venda é: " . $valorVenda;
    }
    ?>
</body>
</html>